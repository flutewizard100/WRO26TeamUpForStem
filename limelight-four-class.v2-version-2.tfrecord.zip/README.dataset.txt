# limelight-four-class > Version 2
https://universe.roboflow.com/sg492-georgetown-edu/limelight-four-class

Provided by a Roboflow user
License: CC BY 4.0

